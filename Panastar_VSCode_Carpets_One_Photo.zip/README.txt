PANASTAR HOUSEHOLD WEBSITE

Open index.html in VS Code with Live Server.

OR run:
python -m http.server 8000

Then visit:
http://localhost:8000

Phone/WhatsApp: +254 726 048 447
Email: rebeccakinyanjui@gmail.com
Facebook: Becky Kinyanjui
TikTok: @panastar.househol
Location: Githurai, Nairobi & surrounding areas

No product prices are displayed.
Every catalogue product now has an individual photo.
The requested Brooms, Mops, Towels, Basins, Buckets, Sufuria, Spoons and Plates photos are bundled locally.
The additional catalogue photos use free Unsplash photo URLs.
