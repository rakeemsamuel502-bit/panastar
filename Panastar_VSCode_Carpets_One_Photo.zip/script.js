const products = [
  {name:"Spoons",cat:"kitchen",desc:"Stainless-steel spoons for dining and everyday use.",icon:"fa-spoon",photo:"spoons.jpg"},
  {name:"Plates",cat:"kitchen",desc:"Durable plates for everyday meals and serving.",icon:"fa-plate-wheat",photo:"plates.jpg"},
  {name:"Sufuria / Cooking Pots",cat:"kitchen",desc:"Cooking pots suitable for everyday Kenyan kitchens.",icon:"fa-pot-food",photo:"sufuria.jpg"},
  {name:"Brooms",cat:"cleaning",desc:"Practical household brooms for keeping your home and compound clean.",icon:"fa-broom",photo:"brooms.jpg"},
  {name:"Mops",cat:"cleaning",desc:"Floor-cleaning mops for everyday household cleaning.",icon:"fa-broom",photo:"mops.jpg"},
  {name:"Towels",cat:"bedroom",desc:"Soft and absorbent towels for bath and household use.",icon:"fa-towel",photo:"towels.jpg"},
  {name:"Basins",cat:"cleaning",desc:"Household basins for washing, cleaning and everyday tasks.",icon:"fa-circle",photo:"basins.jpg"},
  {name:"Buckets",cat:"cleaning",desc:"Strong household buckets for cleaning and everyday use.",icon:"fa-bucket",photo:"buckets.jpg"},
  {name:"Mattresses",cat:"bedroom",desc:"Comfortable mattresses for everyday sleeping and bedroom setup.",icon:"fa-bed",photo:"https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=85"},
  {name:"Pillows",cat:"bedroom",desc:"Soft and supportive pillows for comfortable rest.",icon:"fa-cloud",photo:"https://images.unsplash.com/photo-1552420085-4c52b37a25a2?auto=format&fit=crop&w=800&q=85"},
  {name:"Bedsheets",cat:"bedroom",desc:"Comfortable bedsheets in different designs and sizes.",icon:"fa-bed",photo:"https://images.unsplash.com/photo-1717160111671-606fa1563d53?auto=format&fit=crop&w=800&q=85"},
  {name:"Carpets",cat:"bedroom",desc:"Stylish and comfortable carpets for living rooms, bedrooms and other spaces. Available in a range of designs and sizes.",icon:"fa-rug",photo:"carpets.jpg"},

  {name:"Cups & Mugs",cat:"drinkware",desc:"Cups and mugs for tea, coffee and everyday drinks.",icon:"fa-mug-hot",photo:"https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=800&q=85"},
  {name:"Drinking Glasses",cat:"drinkware",desc:"Everyday glassware for water, juice and other drinks.",icon:"fa-glass-water",photo:"https://images.unsplash.com/photo-1522011308668-2e255e60de67?auto=format&fit=crop&w=800&q=85"},
  {name:"Bowls",cat:"kitchen",desc:"Kitchen and serving bowls for food preparation and meals.",icon:"fa-bowl-food",photo:"https://images.unsplash.com/photo-1782170376789-74fd73fafe94?auto=format&fit=crop&w=800&q=85"},
  {name:"Frying Pans",cat:"kitchen",desc:"Everyday frying pans for a range of kitchen tasks.",icon:"fa-pan-frying",photo:"https://images.unsplash.com/photo-1633859159647-11134b20658f?auto=format&fit=crop&w=800&q=85"},
  {name:"Kitchen Knives",cat:"kitchen",desc:"Kitchen knives for everyday food preparation.",icon:"fa-kitchen-set",photo:"https://images.unsplash.com/photo-1495195134817-aeb325a55b65?auto=format&fit=crop&w=800&q=85"},
  {name:"Cooking Utensils",cat:"kitchen",desc:"Serving spoons, spatulas, ladles and other useful utensils.",icon:"fa-utensils",photo:"https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=85"},
  {name:"Water Dispensers",cat:"drinkware",desc:"Water dispensers suitable for homes and offices.",icon:"fa-faucet-drip",photo:"https://images.unsplash.com/photo-1780590107766-28714e165924?auto=format&fit=crop&w=800&q=85"},
  {name:"Water Bottles",cat:"drinkware",desc:"Reusable bottles for home, school, work and travel.",icon:"fa-bottle-water",photo:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=85"},
  {name:"Thermos Flasks",cat:"drinkware",desc:"Vacuum flasks for keeping drinks hot or cold.",icon:"fa-temperature-half",photo:"https://images.unsplash.com/photo-1767525804740-e141f0be2614?auto=format&fit=crop&w=800&q=85"},
  {name:"Food Storage Containers",cat:"storage",desc:"Containers for storing and organizing food in the kitchen.",icon:"fa-box",photo:"https://images.unsplash.com/photo-1786417340764-b918ff6e8562?auto=format&fit=crop&w=800&q=85"},
  {name:"Storage Baskets",cat:"storage",desc:"Useful baskets for organizing household spaces.",icon:"fa-basket-shopping",photo:"https://images.unsplash.com/photo-1786396798357-ac8ba6704d89?auto=format&fit=crop&w=800&q=85"},
  {name:"Laundry Baskets",cat:"laundry",desc:"Practical baskets for collecting and organizing laundry.",icon:"fa-basket-shopping",photo:"https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=800&q=85"}
];

const grid=document.getElementById("productGrid");
const search=document.getElementById("searchInput");
const empty=document.getElementById("noResults");
let category="all";

function render(){
  const term=search.value.toLowerCase().trim();
  const list=products.filter(p=>
    (category==="all"||p.cat===category) &&
    (`${p.name} ${p.desc}`).toLowerCase().includes(term)
  );

  grid.innerHTML=list.map(p=>{
    const msg=encodeURIComponent(`Hello Panastar, I am interested in ${p.name}. Please share availability and details.`);
    const visual=p.photo
      ? `<img src="${p.photo}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><i class="fallback fas ${p.icon}" aria-hidden="true" style="display:none"></i>`
      : `<i class="fallback fas ${p.icon}" aria-hidden="true"></i>`;
    return `<article class="product-card">
      <div class="product-photo">${visual}</div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <a class="order" href="https://wa.me/254726048447?text=${msg}" target="_blank" rel="noopener"><i class="fab fa-whatsapp"></i> Order / enquire</a>
      </div>
    </article>`;
  }).join("");

  empty.style.display=list.length?"none":"block";
}

document.querySelectorAll(".category-row button").forEach(btn=>{
  btn.addEventListener("click",()=>{
    category=btn.dataset.category;
    render();
    document.getElementById("products").scrollIntoView({behavior:"smooth"});
  });
});

search.addEventListener("input",render);

document.getElementById("menuBtn").addEventListener("click",()=>{
  document.getElementById("navLinks").classList.toggle("open");
});

document.querySelectorAll("#navLinks a").forEach(a=>{
  a.addEventListener("click",()=>document.getElementById("navLinks").classList.remove("open"));
});

render();
